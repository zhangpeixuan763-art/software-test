from __future__ import annotations

import argparse
import csv
import random
from pathlib import Path


SYSTEMS = [
    ("S1", "OrderSvc", 18.7, 326, 11, 18),
    ("S2", "PayCore", 31.4, 512, 17, 21),
    ("S3", "ReportGen", 24.2, 284, 9, 14),
    ("S4", "MsgQueue", 46.8, 734, 23, 19),
    ("S5", "WebShop", 52.1, 901, 27, 22),
    ("S6", "DataPipe", 67.5, 1180, 31, 16),
]


def write_csv(path: Path, fields: list[str], rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def weighted_sample(rng: random.Random, items: list[str], weights: dict[str, float], k: int) -> list[str]:
    selected: list[str] = []
    pool = list(items)
    for _ in range(min(k, len(pool))):
        total = sum(weights[x] for x in pool)
        pick = rng.random() * total
        acc = 0.0
        for idx, item in enumerate(pool):
            acc += weights[item]
            if acc >= pick:
                selected.append(item)
                del pool[idx]
                break
    return selected


def generate(out_dir: Path, seed: int = 20260623) -> None:
    rng = random.Random(seed)
    systems_rows = []
    entity_rows = []
    test_rows = []
    coverage_rows = []
    version_rows = []
    changed_rows = []
    fault_rows = []

    for sid, name, kloc, test_count, fault_count, version_count in SYSTEMS:
        entity_count = max(260, int(kloc * 22.0))
        systems_rows.append(
            {
                "system_id": sid,
                "system": name,
                "kloc": kloc,
                "test_count": test_count,
                "entity_count": entity_count,
                "fault_count": fault_count,
                "version_count": version_count,
            }
        )

        entity_ids = [f"{sid}_E{i:04d}" for i in range(1, entity_count + 1)]
        entity_risk = {}
        for idx, eid in enumerate(entity_ids, 1):
            hot = 1.0 if idx <= int(entity_count * 0.22) else 0.0
            change_lines = int(rng.expovariate(1 / 14) + hot * rng.randint(15, 55) + 1)
            fan_in = int(rng.expovariate(1 / 3) + hot * rng.randint(1, 8))
            fan_out = int(rng.expovariate(1 / 2) + hot * rng.randint(1, 6))
            history_defects = int(rng.expovariate(1 / 1.4) + hot * rng.randint(0, 6))
            recency_days = int(rng.expovariate(1 / 20) + (0 if hot else rng.randint(10, 90)) + 1)
            entity_risk[eid] = change_lines * 0.03 + (fan_in + fan_out) * 0.2 + history_defects * 0.8 + 20 / (recency_days + 5)
            entity_rows.append(
                {
                    "system_id": sid,
                    "entity_id": eid,
                    "file_path": f"src/{name.lower()}/module_{(idx - 1) // 12:02d}/Entity{idx:04d}.java",
                    "change_lines": change_lines,
                    "fan_in": fan_in,
                    "fan_out": fan_out,
                    "history_defects": history_defects,
                    "recency_days": recency_days,
                }
            )

        tests_covering_entity: dict[str, list[str]] = {eid: [] for eid in entity_ids}
        for i in range(1, test_count + 1):
            tid = f"{sid}_T{i:04d}"
            duration = round(rng.lognormvariate(2.0, 0.55), 2)
            history_failures = max(0, int(rng.expovariate(1 / 0.65)))
            last_failed = 1 if history_failures and rng.random() < 0.45 else 0
            test_rows.append(
                {
                    "system_id": sid,
                    "test_id": tid,
                    "duration_sec": duration,
                    "history_failures": history_failures,
                    "last_failed": last_failed,
                }
            )

            cover_size = rng.randint(2, 6)
            if rng.random() < 0.35:
                cover_size += rng.randint(3, 6)
            covered = weighted_sample(rng, entity_ids, {e: 1.0 + entity_risk[e] * 0.28 for e in entity_ids}, cover_size)
            for eid in covered:
                coverage_rows.append({"system_id": sid, "test_id": tid, "entity_id": eid})
                tests_covering_entity[eid].append(tid)

        for eid, covering in tests_covering_entity.items():
            if not covering:
                tid = f"{sid}_T{rng.randint(1, test_count):04d}"
                coverage_rows.append({"system_id": sid, "test_id": tid, "entity_id": eid})

        faults_remaining = fault_count
        for v in range(1, version_count + 1):
            vid = f"v{v:02d}"
            version_rows.append({"system_id": sid, "version_id": vid, "commit_id": f"{sid.lower()}-{v:03d}"})
            changed_count = rng.randint(max(8, entity_count // 18), max(14, entity_count // 7))
            changed = weighted_sample(rng, entity_ids, {e: 1.0 + entity_risk[e] * 0.35 for e in entity_ids}, changed_count)
            for eid in changed:
                changed_rows.append({"system_id": sid, "version_id": vid, "entity_id": eid})

            versions_left = version_count - v + 1
            faults_here = 0
            if faults_remaining > 0:
                expected = faults_remaining / versions_left
                faults_here = min(faults_remaining, int(expected + rng.random() + (1 if rng.random() < 0.35 else 0)))
            risky_changed = weighted_sample(rng, changed, {e: 1.0 + entity_risk[e] for e in changed}, faults_here)
            for local_idx, eid in enumerate(risky_changed, 1):
                fault_rows.append(
                    {
                        "system_id": sid,
                        "version_id": vid,
                        "fault_id": f"{sid}_{vid}_F{local_idx:02d}",
                        "entity_id": eid,
                    }
                )
            faults_remaining -= faults_here

    write_csv(
        out_dir / "systems.csv",
        ["system_id", "system", "kloc", "test_count", "entity_count", "fault_count", "version_count"],
        systems_rows,
    )
    write_csv(
        out_dir / "entities.csv",
        ["system_id", "entity_id", "file_path", "change_lines", "fan_in", "fan_out", "history_defects", "recency_days"],
        entity_rows,
    )
    write_csv(out_dir / "test_cases.csv", ["system_id", "test_id", "duration_sec", "history_failures", "last_failed"], test_rows)
    write_csv(out_dir / "coverage.csv", ["system_id", "test_id", "entity_id"], coverage_rows)
    write_csv(out_dir / "versions.csv", ["system_id", "version_id", "commit_id"], version_rows)
    write_csv(out_dir / "changed_entities.csv", ["system_id", "version_id", "entity_id"], changed_rows)
    write_csv(out_dir / "faults.csv", ["system_id", "version_id", "fault_id", "entity_id"], fault_rows)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=Path, default=Path("data"))
    parser.add_argument("--seed", type=int, default=20260623)
    args = parser.parse_args()
    generate(args.out, args.seed)


if __name__ == "__main__":
    main()
