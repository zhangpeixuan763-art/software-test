from __future__ import annotations

import csv
import random
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Dict, Iterable, List, Mapping, MutableMapping, Sequence, Set, Tuple


@dataclass(frozen=True)
class Entity:
    system_id: str
    entity_id: str
    file_path: str
    change_lines: float
    fan_in: float
    fan_out: float
    history_defects: float
    recency_days: float


@dataclass(frozen=True)
class TestCase:
    system_id: str
    test_id: str
    duration_sec: float
    history_failures: float
    last_failed: int


@dataclass(frozen=True)
class Fault:
    system_id: str
    version_id: str
    fault_id: str
    entity_id: str


def read_csv(path: Path) -> List[dict]:
    with path.open(newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def write_csv(path: Path, rows: Sequence[Mapping[str, object]], fields: Sequence[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(fields))
        writer.writeheader()
        writer.writerows(rows)


def load_dataset(data_dir: Path) -> dict:
    entities = [
        Entity(
            r["system_id"],
            r["entity_id"],
            r["file_path"],
            float(r["change_lines"]),
            float(r["fan_in"]),
            float(r["fan_out"]),
            float(r["history_defects"]),
            float(r["recency_days"]),
        )
        for r in read_csv(data_dir / "entities.csv")
    ]
    tests = [
        TestCase(
            r["system_id"],
            r["test_id"],
            float(r["duration_sec"]),
            float(r["history_failures"]),
            int(r["last_failed"]),
        )
        for r in read_csv(data_dir / "test_cases.csv")
    ]
    coverage: Dict[Tuple[str, str], Set[str]] = defaultdict(set)
    for r in read_csv(data_dir / "coverage.csv"):
        coverage[(r["system_id"], r["test_id"])].add(r["entity_id"])

    changed: Dict[Tuple[str, str], Set[str]] = defaultdict(set)
    for r in read_csv(data_dir / "changed_entities.csv"):
        changed[(r["system_id"], r["version_id"])].add(r["entity_id"])

    faults = [
        Fault(r["system_id"], r["version_id"], r["fault_id"], r["entity_id"])
        for r in read_csv(data_dir / "faults.csv")
    ]
    return {
        "systems": read_csv(data_dir / "systems.csv"),
        "versions": read_csv(data_dir / "versions.csv"),
        "entities": entities,
        "tests": tests,
        "coverage": coverage,
        "changed": changed,
        "faults": faults,
    }


def _normalize(values: Mapping[str, float]) -> Dict[str, float]:
    if not values:
        return {}
    lo = min(values.values())
    hi = max(values.values())
    if hi == lo:
        return {k: 0.0 for k in values}
    return {k: (v - lo) / (hi - lo) for k, v in values.items()}


def compute_entity_risk(
    entities: Sequence[Entity],
    changed_entities: Set[str],
    weights: Tuple[float, float, float, float] = (0.30, 0.25, 0.30, 0.15),
) -> Dict[str, float]:
    by_id = {e.entity_id: e for e in entities if e.entity_id in changed_entities}
    change = _normalize({eid: e.change_lines for eid, e in by_id.items()})
    structure = _normalize({eid: e.fan_in + e.fan_out for eid, e in by_id.items()})
    history = _normalize({eid: e.history_defects for eid, e in by_id.items()})
    freshness = _normalize({eid: 1.0 / (1.0 + e.recency_days) for eid, e in by_id.items()})

    w_change, w_structure, w_history, w_freshness = weights
    return {
        eid: (
            w_change * change.get(eid, 0.0)
            + w_structure * structure.get(eid, 0.0)
            + w_history * history.get(eid, 0.0)
            + w_freshness * freshness.get(eid, 0.0)
        )
        for eid in by_id
    }


def _duration_norm(tests: Sequence[TestCase]) -> Dict[str, float]:
    return _normalize({t.test_id: t.duration_sec for t in tests})


def _history_norm(tests: Sequence[TestCase]) -> Dict[str, float]:
    return _normalize({t.test_id: t.history_failures for t in tests})


def rank_total(tests: Sequence[TestCase], coverage: Mapping[str, Set[str]]) -> List[str]:
    return [t.test_id for t in sorted(tests, key=lambda t: (-len(coverage[t.test_id]), t.duration_sec, t.test_id))]


def rank_history(tests: Sequence[TestCase]) -> List[str]:
    return [t.test_id for t in sorted(tests, key=lambda t: (-t.history_failures, -t.last_failed, t.duration_sec, t.test_id))]


def rank_random(tests: Sequence[TestCase], seed: int = 7) -> List[str]:
    ids = [t.test_id for t in tests]
    random.Random(seed).shuffle(ids)
    return ids


def rank_additional(tests: Sequence[TestCase], coverage: Mapping[str, Set[str]]) -> List[str]:
    remaining = {t.test_id for t in tests}
    cost = {t.test_id: t.duration_sec for t in tests}
    ordered: List[str] = []
    covered: Set[str] = set()
    while remaining:
        best = max(remaining, key=lambda tid: (len(coverage[tid] - covered), -cost[tid], tid))
        ordered.append(best)
        covered |= coverage[best]
        remaining.remove(best)
    return ordered


def rank_risk_only(
    tests: Sequence[TestCase],
    coverage: Mapping[str, Set[str]],
    risk: Mapping[str, float],
) -> List[str]:
    cost = _duration_norm(tests)
    return [
        t.test_id
        for t in sorted(
            tests,
            key=lambda t: (
                -sum(risk.get(eid, 0.0) for eid in coverage[t.test_id]),
                cost[t.test_id],
                t.test_id,
            ),
        )
    ]


def rank_crtcp(
    tests: Sequence[TestCase],
    coverage: Mapping[str, Set[str]],
    risk: Mapping[str, float],
    alpha: float = 0.30,
    beta: float = 0.48,
    gamma: float = 0.14,
    delta: float = 0.08,
) -> List[str]:
    remaining = {t.test_id for t in tests}
    cost = _duration_norm(tests)
    history = _history_norm(tests)
    ordered: List[str] = []
    covered: Set[str] = set()
    changed = set(risk)

    while remaining:
        def score(tid: str) -> Tuple[float, float, str]:
            cov = coverage[tid] & changed
            new_cov = cov - covered
            coverage_gain = len(new_cov) / max(1, len(changed))
            risk_gain = sum(risk.get(eid, 0.0) for eid in new_cov)
            value = alpha * coverage_gain + beta * risk_gain + gamma * history[tid] - delta * cost[tid]
            return (value, -cost[tid], tid)

        chosen = max(remaining, key=score)
        ordered.append(chosen)
        covered |= coverage[chosen] & changed
        remaining.remove(chosen)
    return ordered


def detection_positions(ordering: Sequence[str], coverage: Mapping[str, Set[str]], faults: Sequence[Fault]) -> Dict[str, int]:
    positions = {tid: i + 1 for i, tid in enumerate(ordering)}
    result: Dict[str, int] = {}
    for fault in faults:
        detecting_tests = [tid for tid in ordering if fault.entity_id in coverage[tid]]
        result[fault.fault_id] = positions[detecting_tests[0]] if detecting_tests else len(ordering)
    return result


def apfd(ordering: Sequence[str], coverage: Mapping[str, Set[str]], faults: Sequence[Fault]) -> float:
    if not faults:
        return 0.0
    n = len(ordering)
    m = len(faults)
    positions = detection_positions(ordering, coverage, faults)
    return max(0.0, min(1.0, 1.0 - sum(positions.values()) / (n * m) + 1.0 / (2 * n)))


def apfdc(
    ordering: Sequence[str],
    coverage: Mapping[str, Set[str]],
    tests_by_id: Mapping[str, TestCase],
    faults: Sequence[Fault],
) -> float:
    if not faults:
        return 0.0
    total_time = sum(tests_by_id[tid].duration_sec for tid in ordering)
    elapsed = 0.0
    detected_time: MutableMapping[str, float] = {}
    for tid in ordering:
        duration = tests_by_id[tid].duration_sec
        midpoint = elapsed + duration / 2.0
        covered = coverage[tid]
        for fault in faults:
            if fault.fault_id not in detected_time and fault.entity_id in covered:
                detected_time[fault.fault_id] = midpoint
        elapsed += duration
    default_time = total_time
    mean_fraction = sum(detected_time.get(f.fault_id, default_time) / total_time for f in faults) / len(faults)
    return max(0.0, min(1.0, 1.0 - mean_fraction))


def budget_fault_rate(
    ordering: Sequence[str],
    coverage: Mapping[str, Set[str]],
    tests_by_id: Mapping[str, TestCase],
    faults: Sequence[Fault],
    budget_fraction: float = 0.20,
) -> float:
    if not faults:
        return 0.0
    total_time = sum(tests_by_id[tid].duration_sec for tid in ordering)
    budget = total_time * budget_fraction
    elapsed = 0.0
    detected: Set[str] = set()
    for tid in ordering:
        if elapsed >= budget:
            break
        elapsed += tests_by_id[tid].duration_sec
        for fault in faults:
            if fault.entity_id in coverage[tid]:
                detected.add(fault.fault_id)
    return len(detected) / len(faults)
