from __future__ import annotations

import argparse
from collections import defaultdict
from pathlib import Path

from crtcp import (
    apfd,
    apfdc,
    budget_fault_rate,
    compute_entity_risk,
    load_dataset,
    rank_additional,
    rank_crtcp,
    rank_history,
    rank_random,
    rank_risk_only,
    rank_total,
    write_csv,
)


METHODS = ("Random", "Total", "Additional", "History", "RiskOnly", "CRTCP")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", type=Path, default=Path("data"))
    parser.add_argument("--out", type=Path, default=Path("results"))
    args = parser.parse_args()

    dataset = load_dataset(args.data)
    entities_by_system = defaultdict(list)
    tests_by_system = defaultdict(list)
    faults_by_version = defaultdict(list)

    for entity in dataset["entities"]:
        entities_by_system[entity.system_id].append(entity)
    for test in dataset["tests"]:
        tests_by_system[test.system_id].append(test)
    for fault in dataset["faults"]:
        faults_by_version[(fault.system_id, fault.version_id)].append(fault)

    detail_rows = []
    summary_acc = defaultdict(lambda: {"apfd": [], "apfdc": [], "budget": []})

    for version in dataset["versions"]:
        sid = version["system_id"]
        vid = version["version_id"]
        faults = faults_by_version[(sid, vid)]
        if not faults:
            continue

        tests = tests_by_system[sid]
        tests_by_id = {t.test_id: t for t in tests}
        coverage = {t.test_id: dataset["coverage"][(sid, t.test_id)] for t in tests}
        changed_entities = dataset["changed"][(sid, vid)]
        risk = compute_entity_risk(entities_by_system[sid], changed_entities)

        random_seed = sum((i + 1) * ord(ch) for i, ch in enumerate(f"{sid}-{vid}"))
        rankings = {
            "Random": rank_random(tests, seed=random_seed),
            "Total": rank_total(tests, coverage),
            "Additional": rank_additional(tests, coverage),
            "History": rank_history(tests),
            "RiskOnly": rank_risk_only(tests, coverage, risk),
            "CRTCP": rank_crtcp(tests, coverage, risk),
        }

        for method, ordering in rankings.items():
            row = {
                "system_id": sid,
                "version_id": vid,
                "method": method,
                "apfd": round(apfd(ordering, coverage, faults) * 100, 2),
                "apfdc": round(apfdc(ordering, coverage, tests_by_id, faults) * 100, 2),
                "budget20_fault_rate": round(budget_fault_rate(ordering, coverage, tests_by_id, faults) * 100, 2),
            }
            detail_rows.append(row)
            summary_acc[(sid, method)]["apfd"].append(row["apfd"])
            summary_acc[(sid, method)]["apfdc"].append(row["apfdc"])
            summary_acc[(sid, method)]["budget"].append(row["budget20_fault_rate"])

    summary_rows = []
    for (sid, method), values in sorted(summary_acc.items()):
        summary_rows.append(
            {
                "system_id": sid,
                "method": method,
                "apfd": round(sum(values["apfd"]) / len(values["apfd"]), 2),
                "apfdc": round(sum(values["apfdc"]) / len(values["apfdc"]), 2),
                "budget20_fault_rate": round(sum(values["budget"]) / len(values["budget"]), 2),
            }
        )

    write_csv(
        args.out / "version_results.csv",
        detail_rows,
        ["system_id", "version_id", "method", "apfd", "apfdc", "budget20_fault_rate"],
    )
    write_csv(
        args.out / "summary_by_system.csv",
        summary_rows,
        ["system_id", "method", "apfd", "apfdc", "budget20_fault_rate"],
    )

    print(f"Wrote {args.out / 'version_results.csv'}")
    print(f"Wrote {args.out / 'summary_by_system.csv'}")


if __name__ == "__main__":
    main()
